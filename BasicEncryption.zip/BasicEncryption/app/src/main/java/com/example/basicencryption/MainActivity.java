package com.example.basicencryption;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText ets1,ets2,ets3;
    private Button enc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        encrypt1();
    }
    public void encrypt1()
    {
        ets1=(EditText)findViewById(R.id.et1);
        ets3=(EditText)findViewById(R.id.et);
        ets2=(EditText)findViewById(R.id.et2);
        enc=(Button)findViewById(R.id.btenc);

        enc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String encr1=ets1.getText().toString();
                Integer shift=Integer.parseInt(ets3.getText().toString());
                StringBuffer x=new StringBuffer();
                x=encrypt(encr1,shift);
                ets2.setText(x);
            }
        });
    }
    public StringBuffer encrypt(String e,Integer s)
    {
        StringBuffer result=new StringBuffer();
        for(int i=0;i<e.length();i++)
        {
            if(Character.isUpperCase(e.charAt(i)))
            {
                char ch=(char)(((int)e.charAt(i)+s-65)%26+65);
                result.append(ch);

            }
            else
            {
                char ch=(char)(((int)e.charAt(i)+s-97)%26+97);
                result.append(ch);
            }


        }
        return result;
    }
}

