package com.example.convertor;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends Activity {

    private Spinner sp1, sp2;
    private Button btnConvert;
    private EditText etn1,etn2;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
            sp1 = (Spinner) findViewById(R.id.spinner1);
            sp2 = (Spinner) findViewById(R.id.spinner2);
            etn1 = (EditText) findViewById(R.id.etno1);
            etn2 = (EditText) findViewById(R.id.res);
            btnConvert = (Button) findViewById(R.id.bt_conv);


            btnConvert.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Integer x = sp1.getSelectedItemPosition();
                    Integer y = sp2.getSelectedItemPosition();
                    Double n1 = Double.parseDouble(etn1.getText().toString());
                    Double result = 0.0;

                    if (x == 0) {
                        if (y == 1) {
                            result = n1 / 10;
                        } else if (y == 2) {
                            result = n1 / 1000;
                        } else if (y == 3) {
                            result = n1 / 1000000;
                        } else {
                            result = n1;
                        }

                    } else if (x == 1) {
                        if (y == 0) {
                            result = n1 * 10;
                        } else if (y == 2) {
                            result = n1 / 100;
                        } else if (y == 3) {
                            result = n1 / 100000;
                        } else {
                            result = n1;
                        }

                    } else if (x == 2) {
                        if (y == 0) {
                            result = n1 * 1000;
                        } else if (y == 1) {
                            result = n1 * 100;
                        } else if (y == 3) {
                            result = n1 / 1000;
                        } else {
                            result = n1;
                        }

                    } else if (x == 3) {
                        if (y == 0) {
                            result = n1 * 1000000;
                        } else if (y == 1) {
                            result = n1 * 100000;
                        } else if (y == 2) {
                            result = n1 * 1000;
                        } else {
                            result = n1;
                        }

                    }
                    etn2.setText("" + result);
                }

            });
        }
        catch (Exception e)
        {
            Toast.makeText(MainActivity.this,"Error:"+e,Toast.LENGTH_SHORT);
        }

    }

}